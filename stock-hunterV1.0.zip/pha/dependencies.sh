#!/usr/bin/bash

pip3 install requests
pip3 install ta
pip3 install pandas
pip3 install prettytable
