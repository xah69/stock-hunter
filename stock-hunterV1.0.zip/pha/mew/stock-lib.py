import requests,time
import pandas as pd
from datetime import datetime
import sys
from ta.utils import dropna
from ta.volatility import BollingerBands
from ta.momentum import RSIIndicator
from ta.trend import EMAIndicator
from ta.trend import MACD
import config
from prettytable import PrettyTable
#from tabulate import tabulate
import numpy as np


# initiation
R = "\033[1;31;40m" #RED
G = "\033[1;32;40m" # GREEN
Y = "\033[1;33;40m" # Yellow
B = "\033[1;34;40m" # Blue
N = "\033[0m" # Reset

lookback = sys.argv[1]
period = sys.argv[2]
p1 = lookback.split("/")
day = int(p1[0])
month = int(p1[1])
year = int(p1[2])





# gets candlestick
def datetotimestamp(date):
    time_tuple = date.timetuple()
    timestamp = round(time.mktime(time_tuple))
    return timestamp
    
def timestamptodate(timestamp):
	date_time = datetime.fromtimestamp(timestamp)    
	return str(date_time)

def get_candle(symbol,start,time):
    #end date
    end = datetotimestamp(datetime.today())

    #fetch candle
    url = "https://priceapi.moneycontrol.com/techCharts/indianMarket/stock/history?symbol="+symbol+"&resolution="+time+"&from="+str(start)+"&to="+str(end)
    resp = requests.get(url).json()
    
    #create data
    data = pd.DataFrame(resp)
    
    #convert unix to ist
    date = []
    for dt in data["t"]:
        date.append({"Date":timestamptodate(dt)})
    dt = pd.DataFrame(date)
    data["t"] = dt["Date"]
    
    #set label
    data.columns = ['?','time', 'Open', 'High', 'Low', 'Close', 'Volume']
    
    #del trash
    del data["?"]  
    #print(symbol) 
    #print(data.to_string())
    #print(data)
    return data


# calculate all stocks indicator

def calc_rsi(data):
	rsi = RSIIndicator(close=data["Close"],window=14)
	data["rsi"] = rsi.rsi()
	return rsi


def prey_rsi(data):
    rsi3d = data["rsi"].tail(3)
    rsi2d = list(rsi3d.iloc[0:2])
    prsi = float(rsi2d[0])
    crsi = float(rsi2d[1])
     
    if crsi > config.rsi["oversold_low"] and crsi < config.rsi["oversold_high"]:
        signal = R+"oversold"+N
        return signal
    
    elif crsi > config.rsi["overbought_low"] and crsi < config.rsi["overbought_high"]:
        signal = G+"overbought"+N
        return signal
    
    elif prsi <= config.rsi["buy_low"] and crsi >= config.rsi["buy_high"]:
        signal = G+"buy"+N
        return signal

    elif prsi >= config.rsi["sell_low"]and crsi <= config.rsi["sell_high"]:
        signal = R+"sell"+N
        return signal
    
    else:
        signal = B+"no signal"+N
        return signal

def calc_bb(data):
    indicator_bb = BollingerBands(close=data["Close"], window=20, window_dev=2)
    data["bb_high"] = indicator_bb.bollinger_hband()
    data["bb_mid"] = indicator_bb.bollinger_mavg()
    data["bb_low"] = indicator_bb.bollinger_lband()

def prey_bb(data):
    p3d = data["Close"].tail(3)
    p2d = list(p3d.iloc[0:2])
    pp = float(p2d[0])
    cp = float(p2d[1])
    
    anotherone = data["Close"].tail(4)
    ao1 = list(anotherone.iloc[0:1])
    t31 = float(ao1[0]) 
    mew = data["bb_low"].tail(4)
    mew1 = list(mew.iloc[0:1])
    mew2 = float(mew1[0])
    mewh = data["bb_low"].tail(4)
    mew1h = list(mewh.iloc[0:1])
    mew2h = float(mew1h[0])


    bbh3d = data["bb_high"].tail(3)
    bbh2d = list(bbh3d.iloc[0:2])
    pbbh = float(bbh2d[0])
    cbbh = float(bbh2d[1])

    bbl3d = data["bb_low"].tail(3)
    bbl2d = list(bbl3d.iloc[0:2])
    pbbl = float(bbl2d[0])
    cbbl = float(bbl2d[1])

    if pp <= pbbl and cp > cbbl and cp > pp:
        signal = G+"weak buy"+N
        return signal
    elif  t31 <= mew2 and pp > pbbl and cp > cbbl and pp > t31 and cp > pp:
        signal = G+"strong buy"+N
        return signal
    elif cp <= cbbl:
        signal = R+"oversold"+N
        return signal
    
    elif  t31 >= mew2 and pp < pbbl and cp < cbbl and pp < t31 and cp < pp:
        signal = R+"strong sell"+N
        return signal
    elif pp >= pbbh and cp < cbbh and cp < pp:
        signal = R+"weak sell"+N
        return signal
    elif cp >= cbbh:
        signal = G+"overbought"+N
        return signal

    else:
        signal = B+"no signal"+N
        return signal

def calc_ema(data):
	ema = EMAIndicator(close=data["Close"],window=14,fillna=False)
	data["ema"] = ema.ema_indicator()
	#print(data["ema"])
	#print(data["Close"])	
	return ema

def prey_ema(data):
	ema3d = data["ema"].tail(3)
	ema2d = list(ema3d.iloc[0:2])
	cema = float(ema2d[1])

	cema3d = data["Close"].tail(3)
	cema2d = list(cema3d.iloc[0:2])
	ccema = float(cema2d[1])
	val = 0.1	
	if ccema > cema:
		cak = ((ccema - cema) / ccema) * 100
		if cak <= val:
			return (B+"nearby middle"+N)
		elif cak > val and cak < 1:
			return (G+"up"+N)
		elif cak >= 1:
			return (G+"up 1+%"+N)
	if ccema < cema:
		cak = ((cema - ccema)/100) * 100
		if cak <= val:
			return (B+"nearby middle"+N)
		elif cak > val and cak < 1:
			return (R+"down"+N)
		elif cak >= 1:
			return (R+"down 1+%"+N)

def calc_emac(data):
	ema1 = EMAIndicator(close=data["Close"],window=14,fillna=False)
	data["ema"] = ema1.ema_indicator()
	ema2 = EMAIndicator(close=data["Close"],window=14,fillna=False)
	data["ema"] = ema2.ema_indicator()
	
	#print(data["ema"])
	#print(data["Close"])	
	return ema

def calc_macd(data):
	macD = MACD(close=data["Close"],window_slow=26,window_fast=12,window_sign=9,fillna=False)
	data["macd"] = macD.macd()
	data["macd_diff"] = macD.macd_diff()
	data["macd_signal"] = macD.macd_signal()
	#print(data["macd"],data["macd_diff"],data["macd_signal"],data["Close"])

def prey_macd(data):
	macd3d = data["macd"].tail(3)
	macd2d = list(macd3d.iloc[0:2])
	pmacd = float(macd2d[0])
	cmacd = float(macd2d[1])
	
	macds3d = data["macd_signal"].tail(3)
	macds2d = list(macds3d.iloc[0:2])
	pmacds = float(macds2d[0])
	cmacds = float(macds2d[1])

	if pmacd < pmacds and cmacd > cmacds:
		return (G+"buy"+N)
	elif pmacd > pmacds and cmacd < cmacds:
		return (R+"sell"+N)
	elif cmacd > cmacds:
		return (G+"bullish"+N)
	elif cmacd < cmacds:
		return (R+"bearish"+N)
	elif cmacd == cmacds:
		return (B+"neutral"+N)



def prey():
	columns = ["stock","rsi","bb","macd","ema"]
	mytable = PrettyTable()
	pear = []	
	rsi = []
	bb = []   
	ema = []
	macde = []	
	start = datetotimestamp(datetime(year,month,day))
	result = {}
	



	for pair in config.data["pairs"]:
		globals()[pair] = get_candle(pair,start,str(period))
		rsi_calc = calc_rsi(globals()[pair])
		rsi_scan = prey_rsi(globals()[pair])
		calc_bb(globals()[pair])
		bb_scan = prey_bb(globals()[pair])

		calc_ema(globals()[pair])
		emo = prey_ema(globals()[pair])
		result[(pair+"_rsi")] = rsi_scan
		result[(pair+"_bb")] = bb_scan
		#print(pair)
		#print(globals()[pair])

		calc_macd(globals()[pair])
		mo = prey_macd(globals()[pair])
		
		

		pear.append(pair)
		rsi.append(rsi_scan)
		bb.append(bb_scan)
		ema.append(emo)
		macde.append(mo)
	#print(pear,rsi,bb)
	#print(macde)
	mytable.add_column(columns[0],pear)
	mytable.add_column(columns[1],rsi)
	mytable.add_column(columns[2],bb)
	mytable.add_column(columns[3],macde)
	mytable.add_column(columns[4],ema)
	#print(mytable)
	return mytable



# initiation
"""
lookback = sys.argv[1]
p1 = lookback.split("/")
day = int(p1[0])
month = int(p1[1])
year = int(p1[2])
print(year)
print(month)
print(day)
#trash

t = 15
start = datetotimestamp(datetime(2022,9,1))
#end = datetotimestamp(datetime.today())
#symbol = "INFY"
data = get_candle("TATASTEEL",start,"15")
#get_candle("TATASTEEL",start,"1W")
get_candle("INFY",start,"15")
#get_candle("INFY",start,"1W")

ptf = prev_t(data)
ctf = current_t()
pt = to_min(ptf)
ct = to_min(ctf)
dt = delta_t(pt,ct)
st = sleep_t(dt,t)

print(pt," | ",ct)
print(to_min(ptf)," | ",to_min(ctf))
print(dt," | ",st)
"""
print(prey())































