data = {
        
        "pairs":["INFY","TATASTEEL","DABUR"],
        "interval":1
        
        }

rsi = {
        #rsi overbought range
        "overbought_low":69,
        "overbought_high":71,

        #rsi oversold range
        "oversold_low":29,
        "oversold_high":31,
        
        #buy range
        "buy_low":30,
        "buy_high":31,
        
        #sell range
        "sell_low":70,
        "sell_high":71
        
        }




