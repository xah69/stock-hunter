import os
import requests

# initiation
R = "\033[1;31;45m" #RED
G = "\033[1;32;45m" # GREEN
Y = "\033[1;33;45m" # Yellow
B = "\033[1;34;45m" # Blue
N = "\033[0m" # Reset

os.system("clear")

def read_line(fileName):
    file1 = open(fileName,"r")
    lines = file1.readlines()
    return lines

line = read_line("test.txt")

for i in line:
    print(i.rstrip("\n"))
while True:
    print("[ Intraday = i | Position = p ]")
    cmd = input("--> ")

    if cmd == "i":
        j = input("> [enter starting date] --$  ")
        l = input("> [enter time period  ] --$  ")
        k = "python3 /home/ibang/py/pha/stock-lib.py " + j + " " + l
        os.system(k)

    elif cmd == "p":
        j = input("> [enter starting date] --$  ")
        l = input("> [enter time period  ] --$  ")
        k = "python3 /home/ibang/py/pha/mew/stock-lib.py " + j + " " + l
        os.system(k)
    elif cmd == "c":
        os.system("clear")
    elif cmd == "q":
        break
    else:
        print("command not found")

